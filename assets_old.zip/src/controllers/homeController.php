<?php

namespace src\Controllers;

use src\utils\jwtAuth;
use src\Controllers\Controller;
use src\Models\permissaoModel;

class homeController extends Controller
{
  function index()
  {
    $dados = array();
    $permissao = new permissaoModel();
    $permi = $permissao->getPermissao();
    $dados['permissoes'] = $permi;
    if (!empty($_SESSION['user'])) {
      $user =  unserialize($_SESSION['user']);
      $dados['usuario'] = $user;
    }
    $dados['news'] = $this->getNews();

    $this->renderClient(true, 'client\home', $dados);
  }

  public function getNews(){
    $file = file_get_contents('https://g1.globo.com/rss/g1/ap/amapa/');
    $xml = simplexml_load_string($file, null, LIBXML_NOCDATA);
    $countNews = 0;
    $news = [];

    foreach($xml->channel->item as $item){
      if($countNews === 5) break;
      array_push($news, [
        'img' => $item->children('media', True)->content->attributes(),
        'title' => $item->title,
        'url' => $item->link
      ]);

      $countNews++;
    }
    
    return $news;
  }
}
