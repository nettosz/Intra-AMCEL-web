
<div class="container-search">
  <form>
    <div class="search">
      <label>
        <input
          class="form-control"
          type="text"
          placeholder="Pesquisar por palavra passe"
        />
        <i class="fa fa-search"> </i>
      </label>
    </div>
  </form>
</div>

<section class="menu-options">
  <a href="<?= BASE_URL ?>usuario/perfil" class="menu-item">
    <img src="<?= BASE_URL ?>assets/imgs/user.png" alt="user" />
    <label> PERFIL </label>
  </a>
  <a href="<?= BASE_URL ?>ramais-contatos" class="menu-item">
    <img src="<?= BASE_URL ?>assets/imgs/fone.png" alt="user" />
    <label> RAMAL </label>
  </a>
  <a href="<?= BASE_URL ?>politicas" class="menu-item">
    <img src="<?= BASE_URL ?>assets/imgs/politicas.png" alt="user" />
    <label> POLITICAS </label>
  </a>
  <a href="#" class="menu-item">
    <img src="<?= BASE_URL ?>assets/imgs/security.png" alt="user" />
    <label> LGPD </label>
  </a>
  <a href="#" class="menu-item">
    <img src="<?= BASE_URL ?>assets/imgs/book.png" alt="user" />
    <label> PROCEDIMENTO DEPARTAMENTAL </label>
  </a>
  <a href="<?php BASE_URL;?>admin/home" class="menu-item">
    <img src="<?= BASE_URL ?>assets/imgs/admin.png" alt="user" />
    <label> ADMIN </label>
  </a>
  <a href="<?php BASE_URL;?>agendamento-salas" class="menu-item">
    <img src="<?= BASE_URL ?>assets/imgs/salas.png" alt="user" />
    <label> AGENDAMENTO SALAS </label>
  </a>
  <a href="<?php BASE_URL;?>base-conhecimento" class="menu-item">
    <img src="<?= BASE_URL ?>assets/imgs/base.png" alt="user" />
    <label> BASE CONHECIMENTO </label>
  </a>
  <a href="<?php BASE_URL;?>videos" class="menu-item">
    <img src="<?= BASE_URL ?>assets/imgs/videos.png" alt="user" />
    <label> VIDEOS EDUCATIVOS </label>
  </a>
</section>

<div class="container-slider" style="margin-bottom: 80px;">
  <div class="title">
    <h3>Notícias</h3>
  </div>
  <div class="swiper-container mySwiper">
    <div class="swiper-wrapper">
      <?php foreach($news as $new):?>
      <a href="<?=$new['url'];?>" class="swiper-slide" target="_blank">
        <img
          style="width: 100%; height: 320px"
          src="<?=$new['img']?>"
          alt=""
        />
        <h4><?=$new['title']?></h4>
      </a>
      <?php endforeach;?>
    </div>
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-pagination"></div>
  </div>
</div>