<?php foreach ($salas as $sala) : ?>
  <option value="<?= $sala['id'] ?>"> <?= $sala['numero'] ?></option>
<?php endforeach; ?>