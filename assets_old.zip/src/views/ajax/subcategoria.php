<?= json_encode($sub_categorias); ?>
