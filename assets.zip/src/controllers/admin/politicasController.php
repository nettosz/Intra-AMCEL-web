<?php

namespace src\Controllers\Admin;

use src\Controllers\Controller;
use src\Models\politicasModel;

class politicasController extends Controller
{
  function index()
  {
    $dados = array();

    $politicaModel = new politicasModel();

    if (!empty($_POST['id'])) {
        $result = $politicaModel->delete($_POST['id']);
        if ($result) $dados['success'] = 'Deletado com sucesso';
        else $dados['erro'] = 'Erro ao deletar';
    }
  
    $dados['politicas'] = $politicaModel->getPoliticas();
    $this->renderAdmin(true, 'admin/politicas/index', $dados);
  }

  public function store(){
    $dados = array();

    $politicaModel = new politicasModel();
    $uploaddir = '../assets/pdf/politicas/';

    $titulo = filter_input(INPUT_POST, 'titulo', FILTER_SANITIZE_STRIPPED);
    $fileName = '';

    if(!empty($_FILES['pdf'])){
        $fileName = $_FILES['pdf']['name'];
        $uploadfile = $uploaddir . basename($_FILES['pdf']['name']);
        move_uploaded_file($_FILES['pdf']['tmp_name'], $uploadfile);

        $id = $politicaModel->save($titulo, $fileName);

        if($id > 0) $dados['success'] = 'Politica salva com sucesso';
        else $dados['erro'] = 'Erro ao salvar'; 
    }

    $this->renderAdmin(true, 'admin/politicas/create', $dados);

  }

  public function edit($params){
    $dados = array();

    $politicaModel = new politicasModel();

    $uploaddir = '../assets/pdf/politicas/';

    $titulo = filter_input(INPUT_POST, 'titulo', FILTER_SANITIZE_STRIPPED);
    $fileName = '';

    if(!empty($_FILES['pdf'])){
        $fileName = $_FILES['pdf']['name'];
        $uploadfile = $uploaddir . basename($_FILES['pdf']['name']);
        move_uploaded_file($_FILES['pdf']['tmp_name'], $uploadfile);

        $id = $politicaModel->update($titulo, $fileName, $params[0]['id']);

        if($id > 0) $dados['success'] = 'Politica alterado com sucesso';
        else $dados['erro'] = 'Erro ao alterar'; 
    }

    $dados['politica'] = $politicaModel->getPolitica($params[0]['id']);

    $this->renderAdmin(true, 'admin/politicas/edit', $dados);
  }
}
