<?php

namespace src\Controllers;

use src\utils\jwtAuth;
use src\Controllers\Controller;
use src\Models\noticiasModel;
use src\Models\permissaoModel;

class homeController extends Controller
{
  function index()
  {
    $dados = array();
    $permissao = new permissaoModel();
    $permi = $permissao->getPermissao();
    $dados['permi'] = $permi;

    if (!empty($_SESSION['user'])) {
      $user =  unserialize($_SESSION['user']);
      $dados['usuario'] = $user;
    }
    $noticiasModel = new noticiasModel();

    $noticias = $noticiasModel->getNoticias();

    $dados['slide1'] = array_filter($noticias, function ($n) {
      return $n['slide'] === '1';
    });

    $dados['slide2'] = array_filter($noticias, function ($n) {
      return $n['slide'] === '2';
    });

    $this->renderClient(true, 'client\home', $dados);
  }

  public function getNewsBrasil()
  {
    $file = file_get_contents('https://g1.globo.com/rss/g1/brasil/');
    $xml = simplexml_load_string($file, null, LIBXML_NOCDATA);
    $countNews = 0;
    $news = [];

    foreach ($xml->channel->item as $item) {
      if ($countNews === 5) break;
      array_push($news, [
        'img' => $item->children('media', True)->content->attributes(),
        'title' => $item->title,
        'url' => $item->link
      ]);

      $countNews++;
    }

    return $news;
  }

  public function getNews()
  {
    $file = file_get_contents('https://g1.globo.com/rss/g1/ap/amapa/');
    $xml = simplexml_load_string($file, null, LIBXML_NOCDATA);
    $countNews = 0;
    $news = [];

    foreach ($xml->channel->item as $item) {
      if ($countNews === 5) break;
      array_push($news, [
        'img' => $item->children('media', True)->content->attributes(),
        'title' => $item->title,
        'url' => $item->link
      ]);

      $countNews++;
    }

    return $news;
  }
}
