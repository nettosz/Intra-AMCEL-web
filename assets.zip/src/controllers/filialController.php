<?php

use src\Controllers\Controller;

class filialController extends Controller
{
  public function index()
  {
  }
}
