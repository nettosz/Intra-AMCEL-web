 <?php echo json_encode($categorias); ?>
