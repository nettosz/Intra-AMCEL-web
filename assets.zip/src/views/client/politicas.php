<div class="container-master">
    <div class="agendamento-container">
        <h1 class="title-container">Politicas</h1>
        <hr />
        <div class="row" style="padding: 20px;">
            <?php foreach($politicas as $p): ?>
                <a class="card-politicas" href="<?=BASE_URL?>assets/pdf/politicas/<?=$p['nome_arquivo']?>">
                    <h5>  <?=$p['titulo']; ?>  </h5>
                    <img src="<?=BASE_URL?>assets/imgs/pdf.png" alt="pdf">
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>
