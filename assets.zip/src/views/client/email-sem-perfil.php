<style>
</style>

<div style="margin-top: 100px;  width: 100%; height: 100%; display:flex; justify-content:center;align-items:center;">
  <div style="background: white; padding:20px;">
    <h6> Usuário sem perfil definido, Favor entre em contato com Administrador do sistema! </h6>
    <p>
      <a href="<?= BASE_URL ?>solicitar-perfil?nome=<?= $nome ?>&email=<?= $email ?>">
        Solicitar Criação de Perfil
      </a>
    </p>
    <p>
      <a href="<?= BASE_URL ?>">
        Voltar página Principal
      </a>
    </p>
  </div>
</div>
